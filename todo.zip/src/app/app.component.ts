import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template:`<carousel>
  <slide>
  <img src="assets/images/back1.jpg" alt="first slide" style="display: block; width: 100%;">
  </slide>
  <slide>
  <img src="assets/images/todo.jpg" alt="first slide" style="display: block; width: 100%;">
  </slide>
  <slide>
  <img src="assets/images/back.jpg" alt="first slide" style="display: block; width: 100%;">
  </slide>
  </carousel>
  `,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Todo';
}






