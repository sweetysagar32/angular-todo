import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { TaskService } from '../services/task.service';

@Component({
  selector: 'app-edit-form',
  templateUrl: './edit-form.component.html',
  styleUrls: ['./edit-form.component.css']
})
export class EditFormComponent implements OnInit {

  editForm: FormGroup;
  submitted: boolean = false;
  constructor(private router: Router,
    private taskservice: TaskService,
    private formBuilder: FormBuilder) { }

  ngOnInit() {
    if (localStorage.getItem("username") != null) 
    {
      let taskId = localStorage.getItem("editTaskId");
      if (!taskId) 
      {
        alert('Invalid Action');
        this.router.navigate(['todo-list']);
        return;
      }
    this.editForm = this.formBuilder.group({
      id: [],
      name: ['', Validators.required] ,
      Status: ['', Validators.required]
    });
    this.taskservice.getTasksById(+taskId).subscribe(data=>{
      this.editForm.setValue(data)
    });
  }
  else{
    this.router.navigate(['/login']);
  }
  }
  onSubmit(){
    this.submitted=true;
    if(this.editForm.invalid){
      return true;
    }
    this.taskservice.edittask(this.editForm.value).subscribe(data=>{alert
      ('record added..!')});
      this.taskservice.getTasks().subscribe();
      this.router.navigate(['todo-list']);
  }
  back(){
    this.router.navigate(['todo-list']);
  }

  }
  

